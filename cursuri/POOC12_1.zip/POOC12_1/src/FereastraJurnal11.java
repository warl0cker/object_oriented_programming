
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;


public class FereastraJurnal11 extends JFrame{
    private JTextArea ta;
    private JButton b1,b2;
 
    
    public FereastraJurnal11(){
        super("Jurnal");
        ta=new JTextArea(100,75);
        b1=new JButton("Salveaza");
        b2=new JButton("Anuleaza");
     
        b1.addActionListener( e -> {
           
                try{
                    PrintWriter pw=new PrintWriter(new FileWriter("jurnal.txt", true));
                    pw.println(ta.getText()+"\r\n");
                    pw.close();
                }catch(IOException ioe){ioe.printStackTrace();}
              
                }
        );
        b2.addActionListener( e ->{
                    System.exit(0);
              });
              
        
        add(ta);
        JPanel p=new JPanel();
        p.add(b1);
        p.add(b2);
        add(p, BorderLayout.SOUTH);
    }
   
    public static void main(String[] args){
        JFrame f=new FereastraJurnal1();
        f.setSize(300,400);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
