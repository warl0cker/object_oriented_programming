
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;


public class FereastraJurnal extends JFrame{
    private JTextArea ta;
    private JButton b1,b2;
    private AscultatorButoane ab;
    
    public FereastraJurnal(){
        super("Jurnal");
        ta=new JTextArea(100,75);
        b1=new JButton("Salveaza");
        b2=new JButton("Anuleaza");
        ab=new AscultatorButoane();
        b1.addActionListener(ab);
        b2.addActionListener(ab);
        
        add(ta);
        JPanel p=new JPanel();
        p.add(b1);
        p.add(b2);
        add(p, BorderLayout.SOUTH);
    }
    private class AscultatorButoane implements ActionListener{
        
        public void actionPerformed(ActionEvent e){
            if(e.getSource()==b1){
                try{
                    PrintWriter pw=new PrintWriter(new FileWriter("jurnal.txt", true));
                    pw.println(ta.getText()+"\r\n");
                    pw.close();
                }catch(IOException ioe){ioe.printStackTrace();}
            }
            else System.exit(0);
        }
    }
    public static void main(String[] args){
        JFrame f=new FereastraJurnal();
        f.setSize(300,400);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
