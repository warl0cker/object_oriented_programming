package pooc10_1;
import java.beans.*;
import java.io.*;
public class ManagerFacturi{
 private XMLEncoder en;
 private XMLDecoder dec;
 public ManagerFacturi(){
  try{
   en=new XMLEncoder(new FileOutputStream("factura.xml"));
   dec=new XMLDecoder(new FileInputStream("factura.xml"));
  }catch(IOException io){io.printStackTrace();}
 }
 public void salveaza(Factura f){
  en.writeObject(f);
  en.close();
 }
 public Factura incarca(){
  return (Factura)dec.readObject();
 }
}
