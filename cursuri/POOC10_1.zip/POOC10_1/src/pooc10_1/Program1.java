package pooc10_1;
import java.io.*;
public class Program1 {
    public void scrie(){
        try{
            PrintStream ps=new PrintStream("fisier1.txt");
            System.setOut(ps);
            int n;
            for(int i=1; i<=5; i++){
                n=(int)(Math.random()*10);
                System.out.print(n);
                System.out.print(' ');
            }
            ps.close();
        }catch(IOException e){e.printStackTrace();}
    }
    public static void main(String[] args){
        Program1 p=new Program1();
        p.scrie();
    }
}
