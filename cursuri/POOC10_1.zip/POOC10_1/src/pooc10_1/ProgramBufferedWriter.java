package pooc10_1;
import java.io.*;
public class ProgramBufferedWriter{
 private BufferedWriter bw;
 public ProgramBufferedWriter(){
  try{
      bw=new BufferedWriter(new FileWriter("litere.txt"));
      scrie();
  }catch(IOException e){e.printStackTrace();}
 }
 public void scrie() throws IOException{
  for (char c='a'; c<='z'; c++){
   bw.write(c);
   bw.newLine();//bw.write("\n\r");
  } 
  bw.close();
 }
 public static void main(String[] args){
  new ProgramBufferedWriter();
 }
}
