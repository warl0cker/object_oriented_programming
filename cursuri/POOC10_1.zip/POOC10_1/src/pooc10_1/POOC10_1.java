
package pooc10_1;

public class POOC10_1 {

    public static void main(String[] args) {
   // char c= ConsolaReader.citesteCaracterTastatura();
    
   System.out.println("Ai tastat: "+ConsolaReader.citesteLinieTastatura());
             // TODO code application logic here
    }
    
}
