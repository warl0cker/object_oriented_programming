package pooc10_1;
public class Magazin {
    private String denumire,  adresa;
    private int oraDeschidere, oraInchidere;

    public Magazin(String denumire, String adresa) {
        this.denumire = denumire;
        this.adresa = adresa;
        this.oraDeschidere=10;
        this.oraInchidere=18;
    }

    public Magazin(String denumire, String adresa, int oraDeschidere, int oraInchidere) {
        this.denumire = denumire;
        this.adresa = adresa;
        this.oraDeschidere = oraDeschidere;
        this.oraInchidere = oraInchidere;
    }
    
    public void setOraDeschidere(int orad){
        this.oraDeschidere=orad;
    }
     public void setOraInchidere(int orai){
        this.oraInchidere=orai;
    }

    public String getOrar() {
        return oraDeschidere+":00-"+oraInchidere+":00";
    }

    @Override
    public String toString() {
        return "Magazin{" + "denumire=" + denumire + ", adresa=" + adresa + ", oraDeschidere=" + oraDeschidere + ", oraInchidere=" + oraInchidere + '}';
    }
    
}
