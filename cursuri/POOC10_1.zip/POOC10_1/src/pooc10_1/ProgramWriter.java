package pooc10_1;
import java.io.*;
public class ProgramWriter{
public void scrie(){
  try{
  Writer w=new OutputStreamWriter(new FileOutputStream("sablon.txt"));
  for(int i=1;i<=5;i++){
    w.write(i+" ");
    for(int j=1;j<=i;j++) w.write("*");
    w.write("\n");
  }
  w.close();    
  }catch(IOException ioe){ioe.printStackTrace();}
}
public static void main(String[] args){
 ProgramWriter pw= new ProgramWriter();
 pw.scrie();
 }
}
