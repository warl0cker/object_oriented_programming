package pooc10_1;
import java.io.*;
public class Program3 {
    public char citesteCaracterTastatura(){
        char c='0';
        try{
            c=(char)System.in.read();
            System.in.skip(2);
        }catch(IOException e){e.printStackTrace();}
        return c;
    }
    
    public String citesteLinieTastatura(){
        try{
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            return br.readLine();
                    
        }catch(IOException e){e.printStackTrace();}
        return null;
    }
    
    public String citesteFisier(String numeFisier){
        StringBuffer sb=new StringBuffer();
        
        try{
            BufferedReader br=new BufferedReader(new FileReader(numeFisier));
            while(br.ready())sb.append(br.readLine()+"\n");
            br.close();
            return sb.toString();
                    
        }catch(IOException e){e.printStackTrace();}
        return "";
    }
    
     public static void main(String[] args){
         Program3 p=new Program3();
       //  System.out.println("Tastati un caracter si apoi apasati Enter");
         //System.out.println("Caracterul citit este: "+p.citesteCaracterTastatura());
         
         System.out.println(p.citesteFisier("fisier2.txt"));
     }
}
