package pooc10_1;

public class Plata {
    private double suma, cost;
    public Plata(double s, double c){
        suma=s;
        cost=c;
    }
    public double calculeazaRest(){
        if(suma>=cost) return suma-cost;
        return -1;
    }
}
