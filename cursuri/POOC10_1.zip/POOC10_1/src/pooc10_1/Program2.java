package pooc10_1;
import java.io.*;
public class Program2 {
    public void scrie(){
      try{
            Writer os=new FileWriter("fisier2.txt", true);
            int n;
            os.write("\n");
            for(int i=1; i<=5; i++){
                n=(int)(Math.random()*10+10);
                os.write(n+" ");
                
            }
           // os.flush();
            os.close();
            System.out.println("a fost creat un fisier");
        }catch(IOException e){e.printStackTrace();}
    }
    public static void main(String[] args){
        Program2 p=new Program2();
        p.scrie();
    }
}
