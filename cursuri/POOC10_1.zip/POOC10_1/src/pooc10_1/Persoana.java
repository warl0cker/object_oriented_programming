
package pooc10_1;

public class Persoana implements Client{
    private String nume, prenume, adresa;
    private Vanzare v;
    
    public Persoana(String n, String p, String a){
        this.nume=n;
        this.prenume=p;
        this.adresa=a;
    }
     public void declaraNrArticole(int nr){
      v=new Vanzare(nr);
     }
    public void alegeArticol(String denumire, double p, int c){
    v.adaugaArticol(denumire, p, c);
    }
    public void plateste(double s){
    v.calculeazaTotal();
    v.primestePlata(s);
    if(v.restituieRest()>=0) System.out.println("Restul primit "+v.restituieRest());
    else  System.out.println("Suma insuficienta");
    }
    
    public String getNume(){
        return nume+" "+prenume;
    }
    void afiseazaArticole(){
        for(Articol a: v.getArticole()) System.out.println(a.getProdus().getDenumire());
    }
}
