package pooc10_1;
import java.io.*;
public class ManagerArticole {
    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    
    public void salveaza(Articol a, String numeFisier){
        try{
            oos=new ObjectOutputStream(new FileOutputStream(numeFisier));
            oos.writeObject(a);
            oos.close();
        }catch(IOException e){e.printStackTrace(); 
        }
    }
    public Articol citeste(String numeFisier){
        try{
            ois=new ObjectInputStream(new FileInputStream(numeFisier));
            return (Articol)ois.readObject();
        } catch(Exception e){e.printStackTrace(); }
        return null;
    }
}
