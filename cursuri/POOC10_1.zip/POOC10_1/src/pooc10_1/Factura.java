package pooc10_1;
import java.io.*;
import java.util.*;
public class Factura{
 private static int id=1;
 private int nrFactura;
 private Calendar data;
 private Vanzare v;
 private Articol[] articole;
 public Factura(Vanzare v){
  nrFactura=id++;
  data=Calendar.getInstance();
  this.v=v;
 
  articole=v.getArticole();
 }
 public int getNumar(){
  return nrFactura;
 }
 
 }
