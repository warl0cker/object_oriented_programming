
package pooc10_1;

public class Exceptie{
static void metoda1(int[] a){
  metoda2(a);
}
static void metoda2(int[] b){
  System.out.println(b[0]);
 }
public static void main(String[] args){
 metoda1(null);
}
}