package pooc10_1;
import java.util.*;
import java.io.*;
public class ClasaScanner {
    private static Scanner s = new Scanner(System.in);
    
    public static String citesteOLinieTastatura(){
       String linie=s.nextLine();
       return linie;
    }
    
    public static int citesteNumarIntregTastatura(){
       int nr=-1;
        if(s.hasNextInt()) nr=s.nextInt();
        return nr;
    }
    
      public static double citesteNumarRealTastatura(){
        double nr=-1;
        if(s.hasNextDouble()) nr=s.nextDouble();
        return nr;
    }
    
      public static String citesteContinutFisier(String numeFisier){
          try{
          File f=new File(numeFisier);
          s=new Scanner(f);
          StringBuffer sb=new StringBuffer();
          while(s.hasNextLine()) {
              sb.append(s.nextLine());
              sb.append("\n");
          }
          
          s.close();
          return sb.toString();
      }catch(IOException e){e.printStackTrace();}
          return "";
      }
}
