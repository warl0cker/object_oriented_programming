package pooc10_1;
import java.io.*;
public class ProgramBufferedOutputStream{
public void scrieTriunghi(){
 try{
  BufferedOutputStream bos=new BufferedOutputStream(new FileOutputStream("triunghi.txt"));
  for(int i=1;i<=10;i++){
   for(int j=1;j<=10-i;j++) bos.write(' ');
   for(int j=1;j<=2*i-1;j++) bos.write('*');
   bos.write('\n');
  }
  bos.close();    
  }catch(IOException ioe){ioe.printStackTrace();}
}
 public static void main(String[] args){
        ProgramBufferedOutputStream p=new ProgramBufferedOutputStream();
        p.scrieTriunghi();
    }
}