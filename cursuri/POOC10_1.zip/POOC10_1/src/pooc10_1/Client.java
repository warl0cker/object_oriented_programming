
package pooc10_1;
public interface Client {
    public void declaraNrArticole(int nr);
    public void alegeArticol(String denumire, double p, int c);
    public void plateste(double s);
}
