
package pooc10_1;
import java.io.*;
public class ConsolaReader {
    public static char citesteCaracterTastatura(){
        char c='0';
        try{
            c=(char)System.in.read();
            System.in.skip(2);
            
        }catch(IOException e){e.printStackTrace();}
        return c;
    }
    public static String citesteLinieTastatura(){
        try{
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            return br.readLine();//o linie de caractere pana la Enter
        }catch(IOException e){e.printStackTrace();}
        return null;
    }
    public static String citesteFisier(String nf){
        StringBuffer sb=new StringBuffer();
        String linie;
        
        try{
            BufferedReader br=new BufferedReader(new FileReader(nf));
            
            while((linie=br.readLine())!=null) {
                sb.append(linie);
                sb.append("\n");
            }
             br.close();
        }catch(IOException e){e.printStackTrace();}
        return sb.toString();
        
    }
}
