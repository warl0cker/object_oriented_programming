package pooc10_1;
public class TestManagerArticole {
    public static void main(String[] args){
      //Vanzare v=new Vanzare(2);
        //v.adaugaArticol("creion", 1, 3);
      //  v.adaugaArticol("stilou", 100, 1);
      //  v.calculeazaTotal();
     //   ManagerVanzare mv=ManagerVanzare.getInstanta("articole.txt");
     //   mv.salveaza(v);
  // Articol a=new Articol("stilou", 103, 1);
    ManagerArticole ma=new ManagerArticole();
   //ma.salveaza(a, "articol1.txt");
      
     Articol b=ma.citeste("articol1.txt");
      System.out.println(b.toString()+" cost: "+b.calculeazaCost()+" lei");
    }
}
