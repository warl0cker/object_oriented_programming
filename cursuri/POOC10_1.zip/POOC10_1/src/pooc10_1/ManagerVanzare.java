package pooc10_1;

import java.io.*;
public class ManagerVanzare {
    //m.p. Singleton = un unic obiect
    
    private static ManagerVanzare instanta;
    private PrintWriter pw;
    private ManagerVanzare(String nf){
        try{
        pw=new PrintWriter(new FileWriter(nf, true));
        }catch(IOException e){e.printStackTrace();}
    }
    
    public void salveaza(Vanzare v){
       
            pw.printf("|%s|%s|%s|%-9s|%s", "Nr crt", "Denumire produs", "Cantitate", "Cost", "\n\r");
            Articol[] a=v.getArticole();
            for(var i=0; i<a.length; i++){
                pw.format("|%-6s|%-15s|%-9s|%-9.2f|%s", String.valueOf(i+1), a[i].getProdus().getDenumire(), a[i].getCantitate(), a[i].calculeazaCost(), "\n\r");
            }
            pw.flush();
            pw.close();
  
    }
            
    public static ManagerVanzare getInstanta(String nf){
        if(instanta==null) instanta=new ManagerVanzare(nf);
        return instanta;
    }
}
