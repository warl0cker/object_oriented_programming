package pooc10_1;
import java.io.*;
public class ManagerMagazin{
 public void scrieDateMagazin(Magazin m){
  try{
   FileWriter fw=new FileWriter("datemagazin.txt", true);
   fw.write(m.toString()+"\n");
   fw.close();
  }catch(IOException e){e.printStackTrace();}
 }
 public static void main(String[] args){
  Magazin[] lant=new Magazin[3];
  lant[0]=new Magazin("Constanta", "Aleea trandafirilor", 10, 18);
  lant[1]=new Magazin("Carrefour", "Aleea crinilor", 8, 21);
  lant[2]=new Magazin("Kaufland", "Aleea lalelelor",9, 22);
  ManagerMagazin mm=new ManagerMagazin();
  for (int i=0;i<3;i++)mm.scrieDateMagazin(lant[i]); 
 }
}
