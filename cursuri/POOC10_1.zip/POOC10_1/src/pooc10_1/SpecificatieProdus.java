package pooc10_1;

import java.io.Serializable;

public class SpecificatieProdus implements Comparable<SpecificatieProdus>,Serializable{
    private String denumire;
    private double pretUnitar;
    
    public SpecificatieProdus(String d, double p){
        this.denumire=d;
        this.pretUnitar=p;
    }
    public String getDenumire(){
        return denumire;
    }
    public double getPretUnitar(){
        return this.pretUnitar;
    }
    public int compareTo(SpecificatieProdus sp){
        return denumire.compareTo(sp.denumire);
    }
}
