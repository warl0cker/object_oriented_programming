package pooc10_1;
public class TestScanner {
     public static void main(String[] args){
       System.out.println("Introduceti o linie de la tastatura");
         String l1=ClasaScanner.citesteOLinieTastatura();
          System.out.println("Tastati un numar intreg si un numar real de la tastatura");
          int n1=ClasaScanner.citesteNumarIntregTastatura();
          double d=ClasaScanner.citesteNumarRealTastatura();
        String l2=ClasaScanner.citesteContinutFisier("fisier2.txt");
        System.out.println(l1+"\n"+n1+"\n"+d+"\n"+l2);
       
     }
}
