package pooc10_1;
import java.io.*;
public class ProgramPrintStream{
 public void scrieLitere(String numeFisier){
  try{
   PrintStream fo = new PrintStream(numeFisier);
   System.setOut(fo);
  }catch(FileNotFoundException nfe){nfe.printStackTrace();}
  for(char c='a';c<='z';c++) if(c%2==0)System.out.print(c+" ");
 }
 public static void main(String[] args){
  ProgramPrintStream s=new ProgramPrintStream();
  s.scrieLitere("iesire.txt");
 }
}
