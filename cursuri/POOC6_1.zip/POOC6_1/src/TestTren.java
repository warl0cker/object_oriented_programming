public class TestTren {
    public static void main(String[] args){
        Tren t=new Tren("R680", "Interregio");
        t.efectueazaCalatorie("Constanta", "Bucuresti", 225, 2.30);
         t.efectueazaCalatorie("Constanta", "Brasov", 391, 7.43);
          t.efectueazaCalatorie("Constanta", "Cluj", 644, 9.53);
          t.afiseazaDateCalatorii();
    }
}

