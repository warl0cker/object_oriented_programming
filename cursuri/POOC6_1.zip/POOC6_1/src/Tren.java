
public class Tren {
    private String numar, tip;
    private int viteza;//=0
    private Calatorie[] calatorii;
    private int pozitie;
    
    public Tren(String n, String t){
        numar=n;
        tip=t;
        calatorii=new Calatorie[10];
    }
    public void efectueazaCalatorie(String os, String od, int d, double timp){
        Calatorie c;
        if(pozitie<calatorii.length){
            c=new Calatorie(os, od, d);
            c.setPerioadaTimp(timp);
            calculeazaViteza(c);
            calatorii[pozitie++]=c;
            
        }
        else System.out.println("Eroare");
    }
    private void calculeazaViteza(Calatorie c){
        viteza=(int)(c.getDistanta()/c.getPerioada());
    }
    public void afiseazaDateCalatorii(){
        StringBuffer sb=new StringBuffer();
        sb.append("Trenul ");
        sb.append(numar);
        sb.append(" ");
        sb.append(tip);
        sb.append(" a efectuat:\n");
        for(int i=0; i<pozitie; i++){
            sb.append(calatorii[i].getDateCalatorie());
            sb.append(", viteza: ");
            sb.append(viteza);
            sb.append("km/h\n");
        }
        System.out.println(sb.toString());
    }

}
