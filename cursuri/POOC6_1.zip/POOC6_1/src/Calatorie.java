
public class Calatorie {
    private int distanta;
    private double perioadaTimp;
    private Oras sursa, dest;
    public Calatorie(String os, String od, int d){
        sursa=new Oras(os);
        dest=new Oras(od);
        distanta=d;
    }
    public void setPerioadaTimp(double pt){
        this.perioadaTimp=pt;
    }
    public double getPerioada(){
        return this.perioadaTimp;
    }
    public int getDistanta(){
        return this.distanta;
    }
    public String getDateCalatorie(){
        var sb=new StringBuffer();
        sb.append("o calatorie efectuata intre ");
        sb.append(sursa.getDenumire());
        sb.append(" si ");
        sb.append(dest.getDenumire());
        sb.append(" timp:  ");
        sb.append(this.perioadaTimp);
        return sb.toString();
    }
    
}
