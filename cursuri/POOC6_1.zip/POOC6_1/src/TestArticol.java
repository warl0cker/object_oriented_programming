/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author creng
 */
public class TestArticol {
 public static void main(String[] args){
     Articol[] a=new Articol[2];
     a[0]=new Articol("creion", 0.20, 5);
     a[1]=new Articol("pix", 2.34, 2);
     for(Articol a1:a){
         System.out.println("Ati cumparat: "+a1.getProdus().getDenumire()+" in valoare de: "+a1.calculeazaCost()+" lei");
         
     }
 }   
}
