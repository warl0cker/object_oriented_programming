public class Oras {
 private String denumire;
 public Oras(String d){
     this.denumire=d;
 }
 public String getDenumire(){
     return denumire;
 }
 
}
