
public class Persoana {
    private String nume, prenume;
    public Persoana(String n, String p){
        this.nume=n;
        this.prenume=p;
    }
    public String toString(){
        return nume+" "+prenume;
    }
}
