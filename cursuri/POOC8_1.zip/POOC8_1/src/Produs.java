
public class Produs {//exitinde implicit clasa Object
protected String denumire, cod, material;
protected double pretUnitar, pretVanzare;
public Produs(String d, String c, String m, double pu){
    //super();//se creeaza un obiect Object
    this.denumire=d;
    cod=c;
    material=m;
    this.pretUnitar=pu;
}
//public Produs(){}
public double calculeazaPretVanzare(){
    this.pretVanzare=pretUnitar+pretUnitar*19/100;
    return this.pretVanzare;
}
}
 