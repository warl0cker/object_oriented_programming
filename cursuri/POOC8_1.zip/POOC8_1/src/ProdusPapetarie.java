
public class ProdusPapetarie extends Produs{
    protected String functie;
    public ProdusPapetarie(String d, String c, String m, double pu, String f){
    super(d,c,m,pu); 
     functie=f;
    }
    public String getFunctie(){
        return functie;
    }
    public double calculeazaPretVanzare(int tva){
        return pretVanzare=pretUnitar+tva*pretUnitar/100;
    }
}
