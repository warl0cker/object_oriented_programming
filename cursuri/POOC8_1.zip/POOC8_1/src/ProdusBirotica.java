
public class ProdusBirotica extends Produs{
    private String culoare;
    public ProdusBirotica(String d, String c, String m, double pu, String cul){
    super(d,c,m,pu); 
     culoare=cul;
    }
    
    public double calculeazaPretVanzare(){
        
    super.calculeazaPretVanzare();
    return this.pretVanzare-=5*pretVanzare/100;
}
}
