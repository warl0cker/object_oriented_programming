
public abstract class ContBancar {
    protected double sold;
    protected Persoana proprietar;
    
    public ContBancar(String n, String p){
        proprietar=new Persoana(n,p);//this(n,p,0);
    }
    public ContBancar(String n, String p, double s){
        proprietar=new Persoana(n,p);
        this.sold=s;
    }
    public abstract void depune(double suma);
    public abstract void retrage(double suma);
    public double getSold(){
        return sold;
    }
    public Persoana getProprietar(){
        return proprietar;
    }
    public String toString(){
        StringBuffer sb=new StringBuffer();
         sb.append("tip cont: ");
        sb.append(getClass().getSimpleName());//Class
        sb.append(" are sold: ");
        sb.append(sold);
        sb.append( " este detinut de ");
        sb.append(proprietar);
        return sb.toString();
    }
    
}
