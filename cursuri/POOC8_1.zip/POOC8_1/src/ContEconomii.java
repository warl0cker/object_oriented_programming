
public class ContEconomii extends ContBancar{
private double rataDobanda;

public ContEconomii(String n, String p, double rata){
    super(n,p);
    this.rataDobanda=rata;
}
public ContEconomii(String n, String p, double s, double rata){
    super(n,p,s);
    this.rataDobanda=rata;
}
    public void depune(double suma) {
        if(suma>0) this.sold+=suma;
        
            }

    @Override
    public void retrage(double suma) {
        if(suma<=sold) sold-=suma;
    }
    public void aplicaDobanda(){
        sold+=sold*this.rataDobanda/100;
    }
    public String toString(){
        return super.toString()+" rata dobanda: "+this.rataDobanda;
    }
}
