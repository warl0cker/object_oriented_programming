
public class TestConturi {
    public static void main(String[] args){
        ContBancar[] conturi=new ContBancar[2];
        conturi[0]=new ContEconomii("Ionescu", "Ion", 7.0);
        conturi[1]=new ContCurent("Popescu", "Pop", 3, 0.20);
        for(ContBancar c: conturi){
            c.depune(100);//compilare: se verifica depune e declarata ContBancar
           //pasul 0 la executie se apeleaza depune din ContEconomii
           //pasul 1 la executie se apeleaza depune din ContCurent
            
           System.out.println(c);//toString() 
           if(c instanceof ContEconomii)
                    ((ContEconomii)c).aplicaDobanda();
                         System.out.println(c);//c.toSring()
        }
        
    }
}
