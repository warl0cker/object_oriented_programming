
import java.awt.*;
import javax.swing.*;


public class FDrapel extends JFrame {
    
    public FDrapel(){
       super("Drapelul Romaniei");
       setLayout(new GridLayout(1,3));
        add(new PanouDrapel(1));
         add(new PanouDrapel(2));
          add(new PanouDrapel(3));
    }
    public static void main(String[] args){
        JFrame f=new FDrapel();
        f.setSize(400, 400);
        //f.pack();
        f.setLocationRelativeTo(null);
         f.setVisible(true);
         f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}