
import javax.swing.*;
import java.awt.*;

public class FereastraLogin extends JFrame{
    private JTextField t1;
    private JPasswordField t2;
    private JComboBox cb;
    private JButton b1, b2;
    
   public FereastraLogin(){
        setTitle("Login");
        JPanel p1=new JPanel(new GridLayout(3,2,10,20));
        p1.add(new JLabel("Username"));
        t1=new JTextField(20);
        p1.add(t1);
        p1.add(new JLabel("Parola"));
        t2=new JPasswordField(20);
        p1.add(t2);
        p1.add(new JLabel("Rol"));
        String[] lista={"User", "Admin", "Student", "Profesor"};
        cb=new JComboBox(lista);
        p1.add(cb);
        this.add(p1);
        JPanel p2=new JPanel();
        b1=new JButton("OK");
        p2.add(b1);
         b2=new JButton("Cancel");
        p2.add(b2);
        this.add(p2, BorderLayout.SOUTH);
    }
    public static void main(String[] args){
        JFrame f=new FereastraLogin();
        //f.setSize(300, 250);
        f.pack();
        f.setLocationRelativeTo(null);
        f.setResizable(false);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
