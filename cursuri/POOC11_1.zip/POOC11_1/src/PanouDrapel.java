
import java.awt.Color;
import javax.swing.*;


public class PanouDrapel extends JPanel{
    public PanouDrapel(int i){
        setSize(100, 100);
        switch(i){
           case 1 -> setBackground(Color.red);
           case 2 -> setBackground(Color.yellow); 
           case 3 -> setBackground(Color.blue);
        }
    }
}
