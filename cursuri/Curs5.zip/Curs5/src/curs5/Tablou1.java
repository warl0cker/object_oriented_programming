package curs5;
public class Tablou1 {
    
    public void eliminaElement(int[] a){//P1 a=t; P2 a=b
        if(a.length==1) return;
        int poz=(int)(Math.random()*a.length);
        int[] b=new int[a.length-1];
        System.arraycopy(a, 0, b, 0, poz);
        System.arraycopy(a, poz+1, b, poz,a.length-poz-1);
        for(int e:b) System.out.print(e+" ");
        System.out.println();
        this.eliminaElement(b);//a=b
    }
    
    public static void main(String[] args){
        int[] t=new int[10];
        for(int i=0; i<t.length; i++) t[i]=(int)(Math.random()*90+10);
        for(int e: t) System.out.print(e+" ");
        System.out.println();
        Tablou1 t1=new Tablou1();
        t1.eliminaElement(t);
        for(int e: t) System.out.print(e+" ");
    }
}
