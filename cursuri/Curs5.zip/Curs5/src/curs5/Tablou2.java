package curs5;
import java.util.Arrays;
public class Tablou2 {
    private void afiseaza(int[] a){
        for(int e: a) System.out.print(e+" ");
        System.out.println();
    }
     void afiseaza(int[][] a){
        for(int[] e: a) {
            if(e[0]==0) continue;
            for(int el: e) System.out.print(el+" ");
        System.out.println();
        }
    }
    private int[] sorteaza(int[] a){
        Arrays.sort(a);
        return a;
    }
     private int[] sorteazaB(int[] a){
        int t;
        boolean schimbat;
        for(int i=0; i<a.length-1; i++){
            schimbat=false;
            for(int j=1; j<a.length-i-1;j++){
                if(a[j]>a[j+1]){
                    t=a[j];
                    a[j]=a[j+1];
                    a[j+1]=t;
                    schimbat=true;
                }
            }
            if(schimbat==false) break;
        }
        return a;
    }
      int[][] numaraAparitii(int[] a){
         int[][] rez=new int[a.length][2];
         a=sorteaza(a);
         afiseaza(a);
         int i=0, j=0, n=1;
         while(i<a.length){
             rez[j][0]=a[i];
             rez[j][1]=n;
             if(i<a.length-1){
                 while(a[i]==a[i+1]){
                     n++;
                     i++;
                     if(i==a.length-1) break;
                 }
                 if(n>1){
                      rez[j][1]=n;
                      n=1;
                 }
             }
             i++;
             j++;
         }
         return rez;
         
     }
}
