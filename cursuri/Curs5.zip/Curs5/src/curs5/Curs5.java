/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package curs5;

/**
 *
 * @author creng
 */
public class Curs5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] t={1,3,1,5,7,8,5,1};
        Tablou2 t2=new Tablou2();
        t2.afiseaza(t2.numaraAparitii(t));
    }
    
}
