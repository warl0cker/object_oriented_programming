
public class Articol {
 private int cantitate;
 private SpecificatieProdus produs;
 public Articol(String denumire, double pu, int c){
     produs=new SpecificatieProdus(denumire, pu);
     this.cantitate=c;
 }
 public double calculeazaCost(){
     double cost=produs.getPretUnitar()*cantitate;
     return  cost;
 }
 public SpecificatieProdus getProdus(){
     return produs;
 }
 public int getCantitate(){
     return cantitate;
 }
}
