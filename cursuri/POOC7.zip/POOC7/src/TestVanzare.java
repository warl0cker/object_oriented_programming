
public class TestVanzare {
 public static void main(String[] args){
     Vanzare v=new Vanzare(3);
     v.adaugaArticol("carioca", 5, 2);
     v.adaugaArticol("stick", 20, 1);
     v.adaugaArticol("caiet", 1.20, 3);
     System.out.println("total= "+v.calculeazaTotal());
 } 
}
