
import java.util.Calendar;


public class Vanzare {
private static int TVA=19;
private double total;

private Articol[] articole;
private int pozitie;
public Vanzare(int nrArticole){
    articole=new Articol[nrArticole];
    
}
public void adaugaArticol(String den, double pret, int c){
    if(pozitie<articole.length) articole[pozitie++]=new Articol(den,pret, c);
    
}
public double calculeazaTotal(){
    for(int i=0; i<pozitie; i++) total+=articole[i].calculeazaCost();
    total+=calculeazaTVA();
    Calendar c= Calendar.getInstance();
    if(c.get(Calendar.DAY_OF_WEEK)==1||c.get(Calendar.DAY_OF_WEEK)==7)//aplic reducerea sambata si duminica
    total-=total*5/100;
    return total;    
}
private double calculeazaTVA(){
    return total*TVA/100;
}
}
