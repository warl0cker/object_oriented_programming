
public class SpecificatieProdus {
 private String denumire;
 private double pretUnitar;
 
 public SpecificatieProdus(String d, double pt){
     this.denumire=d;
     this.pretUnitar=pt;
 }
 
 public double getPretUnitar(){
     return this.pretUnitar;
 }
 public String getDenumire(){
     return denumire;
 }
}
