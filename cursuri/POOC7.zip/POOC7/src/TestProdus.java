/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author creng
 */
public class TestProdus {
    public static void main(String[] args){
        Produs p1=new Produs("caiet", "1234", "hartie", 1.2);
       System.out.println(p1.calculeazaPretVanzare());
         ProdusPapetarie p2=new ProdusPapetarie("pic", "1234", "plastic", 0.75, "de sters");
         System.out.println(p2.calculeazaPretVanzare()+" "+p2.getFunctie());
         Produs p3=p2;//p3 refera un obiect al ProdusPapetarie
          System.out.println(p3.calculeazaPretVanzare());// la compilare se verifica daca 
         //metoda calculeazaPretVanzare a fost declarata in Produs
         //la executie, se executa calculeazaPretVanzare mostenita de catre obiectul referit de p3 
         System.out.println( ((ProdusPapetarie)p3).getFunctie());
         Produs[] p=new Produs[3];
         p[0]=p1;
         p[0]=p2;
    }
}
