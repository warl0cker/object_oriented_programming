
public class ContCurent extends ContBancar{
    private int nrTranzactii;
    private final int NR_TRANZACTII_GRATIS;
       private final double COST_TRANZATIE;
    public ContCurent(String n, String p, String a, int ntg, double ct){
    super(n,p,a);
    NR_TRANZACTII_GRATIS=ntg;
    COST_TRANZATIE=ct;
}
public ContCurent(String n, String p, String a,double s, int ntg, double ct){
    super(n,p,a,s);
   NR_TRANZACTII_GRATIS=ntg;
    COST_TRANZATIE=ct;
}

    @Override
    public void depune(double suma) {
     if(suma>0){ sold+=suma;
      this.nrTranzactii++;
     }
    
    }

    @Override
    public void retrage(double suma) {
      if(suma<=sold){ sold-=suma;
      this.nrTranzactii++;
      }
    }
    public void descarcaCheltuieli(){
        if(this.nrTranzactii>this.NR_TRANZACTII_GRATIS){
            retrage((this.nrTranzactii-this.NR_TRANZACTII_GRATIS)*this.COST_TRANZATIE);
            this.nrTranzactii=0;
        }
    }
    public String toString(){
        return super.toString()+", nr tranzactii gratuite "+this.NR_TRANZACTII_GRATIS;
    }
}
