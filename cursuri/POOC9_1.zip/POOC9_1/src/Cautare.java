
import java.util.Arrays;


public interface Cautare {
    
    public default boolean cauta(int[] a, int val){
        Arrays.sort(a);
       // return Arrays.binarySearch(a, val)!=-1; 
    if(Arrays.binarySearch(a, val)!=-1) return true;
    return false;
    }
}
