
public class TestCautareStatica {
    public static void main(String[] args){
        int[] b={3,1,4,2,5,3};
        if(CautareStatica.cauta(b, 4)) System.out.println("L-a gasit");
        else System.out.println("Nu l-a gasit");
    }
}
