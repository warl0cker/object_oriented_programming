public class SpecificatieProdus implements Comparable<SpecificatieProdus>{
    private String denumire;
    private double pretUnitar;
    
    public SpecificatieProdus(String d, double p){
        this.denumire=d;
        this.pretUnitar=p;
    }
    public String getDenumire(){
        return denumire;
    }
    public double getPretUnitar(){
        return this.pretUnitar;
    }
    public int compareTo(SpecificatieProdus sp){
        return this.denumire.compareTo(sp.denumire);
    }
}
