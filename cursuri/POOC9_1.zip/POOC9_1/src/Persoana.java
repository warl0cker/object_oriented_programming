public class Persoana implements Client, Proprietar{
private String nume, prenume, adresa;
private Vanzare v;
private Magazin m;
public Persoana(String nume, String prenume, String adresa){
    this.nume=nume;
    this.prenume=prenume;
    this.adresa=adresa;
}
   
    public void declaraNrArticole(int n) {
      v=new Vanzare(n);
    }

  
    public void alegeArticol(String denumire, double p, int c) {
        v.adaugaArticol(denumire, p, c);


    }

  
    public void plateste(double suma) {
        v.calculeazaTotal();
        v.primestePlata(suma);
        double r=v.restituieRest();
        if (r>=0) System.out.println(r);
        else System.out.println("bani insuficienti");
        
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public String getNume(){
        return nume+" "+prenume;
    }
    
    public void conduce(Magazin m){
        this.m=m;
    }
    public void modificaOrar(int oraD, int oraI){
        m.setOraDeschidere(oraD);
        m.setOraInchidere(oraI);
    }
    public void modificaTVA(int procent){
        Vanzare.TVA=procent;
    }
}