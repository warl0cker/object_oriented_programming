

public class TestClient {
    public static void main(String[] args){
        Client c=new Persoana("ionescu", "ion", "Aleea rozelor 5");
        c.declaraNrArticole(2);
        c.alegeArticol("pix", 2.34, 2);
        c.alegeArticol("caiet", 0.5, 3);
        c.plateste(7);
        System.out.println(((Persoana)c).getNume());
        c=new Persoana("popescu", "ion", "Aleea rozelor 5");
        c.declaraNrArticole(3);
        c.alegeArticol("stilou", 2.34, 2);
        c.alegeArticol("caiet", 0.5, 3);
        c.alegeArticol("carioca", 5, 2);
        c.plateste(30);
        
        Persoana p1=new Persoana("Popescu", "Pop", "Aleea rozelor");
        Proprietar p=p1;
        Magazin m=new Magazin("Auchan", "jjb");
        p.conduce(m);
         System.out.println(m);
        p.modificaOrar(7, 23);
        System.out.println(m);
        
        Client c1=p1;
        c1.declaraNrArticole(1);
        c1.alegeArticol("dsds", 1,23);
        c1.plateste(30);
    }
}
