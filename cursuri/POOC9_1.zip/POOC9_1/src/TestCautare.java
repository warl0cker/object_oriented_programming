
public class TestCautare implements Cautare{
    
    public static void main(String[] args){
        int[] b={3,1,4,2,5,3};
      TestCautare tc=new TestCautare();
      if(tc.cauta(b, 5)) System.out.println("Element gasit!");
       else System.out.println("NU l-a gasit!");
                
    }
}
