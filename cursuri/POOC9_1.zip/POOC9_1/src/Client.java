
public interface Client {
    public void declaraNrArticole(int n);
    public void alegeArticol(String denumire, double p, int c);
    public void plateste(double suma);
}
