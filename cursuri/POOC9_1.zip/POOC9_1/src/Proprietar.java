
public interface Proprietar {
    public void conduce(Magazin m);
    public void modificaOrar(int oraD, int oraI);
    public void modificaTVA(int procent);
}
