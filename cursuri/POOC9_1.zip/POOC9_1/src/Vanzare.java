

import java.util.*;
public class Vanzare {
     static int TVA=19;
    private double total;
    private Articol[] articole;
    private int poz;//=0
    private Plata p;
    public Vanzare(int nra){
        articole=new Articol[nra];//null
    }
    public void adaugaArticol(String denumire, double pretUnitar, int c){
        if(poz<articole.length) articole[poz++]=new Articol(denumire, pretUnitar, c);
        
    }
    private double calculeazaTVA(){
        return total*TVA/100;
    }
    public void calculeazaTotal(){
        for(Articol a: articole)
            if(a!=null) total+=a.calculeazaCost();
        total+=this.calculeazaTVA();
        Calendar c=Calendar.getInstance();//ret ref la unicul obiect al clasei
        if(c.get(Calendar.DAY_OF_WEEK)>=2&&c.get(Calendar.DAY_OF_WEEK)<=5) total-=5*total/100;
    }
    public double getTotal(){
        return total;
    }
    public Articol[] getArticole(){
        return articole;
    }
    public void primestePlata(double suma){
        p=new Plata(suma, total);
    }
    public double restituieRest(){
        return p.calculeazaRest();//m.p.delegation
    }
    public void sorteaza(){
        Arrays.sort(articole);//sorteaza articolele cumparate conform criteriilor implementate de Comparable
    }
}
