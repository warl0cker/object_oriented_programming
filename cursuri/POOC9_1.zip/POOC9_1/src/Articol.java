public class Articol implements Comparable<Articol>{
    private int cantitate;
    private SpecificatieProdus produs;//=null
    public Articol(String denumire, double pretUnitar, int c){
        this.cantitate=c;
        produs=new SpecificatieProdus(denumire, pretUnitar);
    }
    public int getCantitate(){
        return this.cantitate;
    }
    public double calculeazaCost(){
        return cantitate*produs.getPretUnitar();
    }
    public SpecificatieProdus getProdus(){
        return produs;
    }
    public int compareTo(Articol a){
        //this cu obiectul referit de a
        double pc=this.calculeazaCost();
        double ac=a.calculeazaCost();
        if(pc<ac) return -1;
        else if(pc>ac) return 1;
        return produs.compareTo(a.produs);
    }
}
