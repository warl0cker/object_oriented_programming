
public class ProdusBirotica extends Produs{
    private String culoare;
    
    public ProdusBirotica(String d, String c, String m, double pu, String culoare){
        super(d,c,m,pu);
        this.culoare=culoare;
        
    }
     public void calculeazaPretVanzare(int tva){
       this.pretVanzare=pretUnitar+tva*pretUnitar/100;
     }
     
}
