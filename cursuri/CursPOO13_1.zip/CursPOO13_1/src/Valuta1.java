public enum Valuta1 {
    LEU(4.96),DOLAR(1.02),EURO(1);
    private double raporteuro;
    Valuta1(double re){
        raporteuro=re;
    }
    public double getRaport(){        return this.raporteuro;    }

    public void modificatParitateEuro(double r){        this.raporteuro=r;    }

     public static void main(String[] args){
         Valuta1.DOLAR.modificatParitateEuro(1.2);
         System.out.println(Valuta1.DOLAR.getRaport());
     }
}
