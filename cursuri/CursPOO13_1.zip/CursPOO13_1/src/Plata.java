
public class Plata {
    private double cost, suma, rest;
    private Valuta1 v;
    public Plata(double c, double s){
        cost=c;
        suma=s;
    }
    public void specificaValuta(Valuta1 v){
        this.v=v;
    } 
    public void calculeazaRest(){
        if(suma>cost) rest=suma-cost;
        else if(suma<cost){ System.out.println("Suma insuficienta");rest=-1;}
    }
    public String toString(){
        StringBuffer sb=new StringBuffer();
        sb.append("Restul dvs este de ");
        switch(v){
            case DOLAR: sb.append(rest+" $"); break;
            case EURO: sb.append(rest+" euro"); break;
            case LEU: sb.append(rest+" lei"); 
        }
        return sb.toString();
    }
    public static void main(String[] args){
        Plata p = new Plata (100, 134);
        p.specificaValuta(Valuta1.EURO);
        p.calculeazaRest();
        System.out.println(p.toString());
        
    }
}
