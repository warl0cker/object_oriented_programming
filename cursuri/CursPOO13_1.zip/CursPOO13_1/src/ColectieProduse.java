import java.io.*;
import java.util.*;

public class ColectieProduse {
    private ArrayList<Produs> lista;
    private BufferedReader br;
    
    public ColectieProduse(){
        lista=new ArrayList<>();//se creeaza lista vida
        String linie;
        String[] s;
        Produs p;
        try{
            br=new BufferedReader(new FileReader("produse.txt"));
            while((linie=br.readLine())!=null){
                s=linie.split("_");
                p=new ProdusBirotica(s[0], s[1], s[2], Double.parseDouble(s[3]), s[4]);
                lista.add(p);
                //sunt echivalente cu: lista.add(new ProdusBirotica(s[0], s[1]...)
            }
            br.close();
        }catch(IOException e){e.printStackTrace();}
    }
    public String getProduse(){
        StringBuffer sb=new StringBuffer();
        for(int i=0; i<lista.size(); i++){
            lista.get(i).calculeazaPretVanzare();//se apeleaza met mostenita de la Produs
            ((ProdusBirotica)lista.get(i)).calculeazaPretVanzare(9);//se apeleaza met declarat in ProdusBirotica
            sb.append(lista.get(i));//se apeleaza toString()redefinita in Produs
            sb.append("\n");
        }
        return sb.toString();
           
    }
    public void adaugaProdus(String d, String c, String m, double pu, String culoare){
        lista.add(new ProdusBirotica(d,c,m,pu,culoare));
    }
    
    public static void main(String[] args){
        ColectieProduse cp=new ColectieProduse();
        cp.adaugaProdus("foi", "4556", "hartie", 0.1, "alb");
        System.out.println(cp.getProduse());
    }
}
