import java.io.*;
import java.util.*;

public class ExempluProperties {
    private Properties p;
    
    public ExempluProperties(){
     p=new Properties();
     p.put("2", "Ioana");
     p.put("1", "Maria");
     
    }
    public void memoreaza(String nf){
        try{
            p.store(new FileWriter(nf), "Colectie de proprietati");
            System.out.println("Verifica fisierul");
        }catch(IOException e){e.printStackTrace();}
    }
    
    public static void main(String... args){
        ExempluProperties e=new ExempluProperties();
        e.memoreaza("proprietati.txt");
    }
}
