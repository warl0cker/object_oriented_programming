import java.util.*;
public class TreeMapFrecventa { 
    private Map<String, Integer> map;
    private  Map<String, Integer> mapSortat;
    public TreeMapFrecventa(){
        map=new HashMap<>(); 
    }
    public void afiseazaCuvinteDistincte(String[] a){
        String cheie;
   Integer frecventa;
  for (int i=0, n=a.length; i<n; i++) { 
   cheie=a[i];
   frecventa=map.get(cheie);
   if (frecventa==null) frecventa = 1; 
   else frecventa++; 
   map.put(cheie, frecventa); 
  } 
  System.out.println(map.size()+" cuvinte distincte gasite:");
  System.out.println(map); 
    }
    
  public void afiseazaCuvinteOrdonate(){
     mapSortat = new TreeMap<> (map); 
     System.out.println(mapSortat); 
  }
 public static void main(String args[]) {
 TreeMapFrecventa tmf=new TreeMapFrecventa();
 tmf.afiseazaCuvinteDistincte(args);
 tmf.afiseazaCuvinteOrdonate();
   
  
 } 
}
