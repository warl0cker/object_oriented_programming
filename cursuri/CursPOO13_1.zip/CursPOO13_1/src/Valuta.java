public enum Valuta {
    LEU, DOLAR, EURO;
}
