
import java.util.TreeSet;


public class ExempluTreeSet {
    public static void main(String... args){
        TreeSet<String> ts=new TreeSet<>();//Clasa String imp Comparable
        ts.add("veronica");
        ts.add("renata");
        ts.add("ana");
        ts.add("viorel");
        System.out.println(ts);//ts.toString()=>[ana, renata, veronica, viorel]
    }
}
