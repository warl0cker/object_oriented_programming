import java.util.*;
public class Palindrom{
 private String sir;
 public Palindrom(String s){
  sir=s;
 }
 public boolean estePalindrom(){
  ArrayDeque<Character> stiva=new ArrayDeque<>();
  ArrayDeque<Character> coada=new ArrayDeque<>();
  for(int i=0; i<sir.length(); i++){
 	stiva.push(sir.charAt(i));//la inceput
	coada.add(sir.charAt(i));//la sfarsitul
  }
  while(stiva.peek()!=null)
   if (!stiva.pop().equals(coada.remove())) return false;
  return true;	
 }
 public static void main(String[] args){
  Palindrom p=new Palindrom("300103");
  if(p.estePalindrom()) System.out.println("Este palindrom"); 
  else System.out.println("Nu este palindrom");
 }
}
