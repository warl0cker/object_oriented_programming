
public class Produs implements Comparable<Produs> {//extinde implicit Object
    protected String denumire, cod, material;
    protected double pretUnitar, pretVanzare;
    
    public Produs(String d, String c, String m, double pu){
        //super();
        this.denumire=d;
        this.cod=c;
        this.material=m;
        this.pretUnitar=pu;
    }

    
    protected void calculeazaPretVanzare(){
        pretVanzare=pretUnitar+pretUnitar*16/100;
    }
    public double getPretVanzare(){
        return this.pretVanzare;
    }
    public int compareTo(Produs p){
         this.calculeazaPretVanzare();
         p.calculeazaPretVanzare();
         if(pretVanzare>p.pretVanzare) return -1;
         if (this.pretVanzare<p.pretVanzare) return 1;
         return 0;
         
    }
    public String toString(){
        return denumire+" "+String.format("%.2f",pretVanzare);
    }
}
