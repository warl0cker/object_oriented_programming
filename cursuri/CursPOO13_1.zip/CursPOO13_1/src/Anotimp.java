
import java.util.EnumMap;
import java.util.Iterator;


public enum Anotimp {
    IARNA, PRIMAVARA, VARA, TOAMNA;
    public static void main(String... args){
        EnumMap<Anotimp, String> c=new EnumMap<>(Anotimp.class);
        c.put(VARA, "Este foarte cald");
         c.put(PRIMAVARA, "Este rece");
         for(Iterator<Anotimp> it=c.keySet().iterator(); it.hasNext();)
         {
             Anotimp a=it.next();
             System.out.println(a+":"+c.get(a));
         }
    }
}
