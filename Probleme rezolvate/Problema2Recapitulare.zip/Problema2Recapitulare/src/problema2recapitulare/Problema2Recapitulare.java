
package problema2recapitulare;

public class Problema2Recapitulare {
    public static void main(String[] args) {
    new Concurs();
    }
    
}
