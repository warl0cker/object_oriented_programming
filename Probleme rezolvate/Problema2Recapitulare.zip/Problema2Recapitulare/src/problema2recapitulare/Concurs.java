package problema2recapitulare;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Concurs extends JFrame{
	private JButton[] b;
	private AscultatorC a;	
	
	public Concurs(){
	 super ("Concurs de admitere");
	  JPanel p=new JPanel();	
	  p.setLayout(new GridLayout(3,2,10,10));
	  p.setBackground(Color.lightGray);	
	  String[] s=new String[]{"Candidat nou", "Date despre candidati", "Cauta un candidat", "Elimina un candidat"};
	  a=new AscultatorC();	
	 b=new JButton[4];	
	  for (int i=0; i<b.length; i++){
		b[i]=new JButton(s[i]);
		b[i].addActionListener(a);
		p.add(b[i]);
 	   }
	add(p);	
 setSize(375, 175);
 setLocation(300,300);	
 setVisible(true); 	
 addWindowListener(new WindowAdapter(){
   public void windowClosing(WindowEvent e){
   	ColectieCandidati.getInstanta().salveaza();
   	System.exit(0);}
});	
	}
	
	private class AscultatorC implements ActionListener{
		private JFrame f;
		
	 public void actionPerformed(ActionEvent e){
	 
	  if(e.getSource()==b[0]){
	      f=new CandidatNouFrame();
	  	f.pack();
	  	f.setVisible(true);
	  	  
	  }
	 else if(e.getSource()==b[1]){
	   f=new CandidatiFrame();
         f.setVisible(true);
	 }
	 	
	 else if(e.getSource()==b[2]){
    String info=JOptionPane.showInputDialog("Introduceti numarul legitimatiei unui candidat", JOptionPane.OK_CANCEL_OPTION);
    if(info!=null){
	 	Candidat c=ColectieCandidati.getInstanta().cautaCandidat(Integer.parseInt(info));
	 	if (c!=null) {
	 		   f=new NoteCandidatFrame(c);
                           f.setVisible(true);
	 	 }
	 	else JOptionPane.showMessageDialog(Concurs.this, "Acest candidat nu participa la concurs", "Error", JOptionPane.ERROR_MESSAGE);
	 	}	
       }
	 else{ 
	   f=new EliminareCandidatFrame();
         f.setVisible(true);
	  	  
	  }	
	  	
	 }	
 }


}