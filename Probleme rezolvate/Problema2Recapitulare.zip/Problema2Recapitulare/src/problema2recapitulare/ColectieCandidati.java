package problema2recapitulare;
import java.util.*;
import java.io.*; 
import javax.swing.*;
public class ColectieCandidati{
	private TreeSet<Candidat> ts;
	private BufferedReader br;
	private PrintWriter pw;
	private String l;
	private static ColectieCandidati cc;
	
	private ColectieCandidati(){
		File f=new File("candidati.txt");
	  ts=new TreeSet<>(new CandidatComparator());
	  Candidat c=null;
	 if (f.exists()){
	 	try{
	 		br=new BufferedReader(new FileReader(f));
	 		while ((l=br.readLine())!=null){
                                 String[] s=l.split(" ");
	 			 c=new Candidat(Integer.parseInt(s[0]), s[1], s[2], s[3]);
	 			 c.setPrimaNota(Double.parseDouble(s[4]));
                                 c.setADouaNota(Double.parseDouble(s[5]));
	 			 ts.add(c);
	    }
	 	}catch(IOException ioe){ioe.printStackTrace();}	
	
	} else System.out.println("Fisierul nu exista");
	}		
	
	public String getCandidati(){
	 var rez=new StringBuffer();
	 for(Candidat c:ts) rez.append(c.getInformatii()+"\n");
	 return rez.toString();
	}
	
	public Candidat cautaCandidat(int nrLeg){
	   Candidat c=null;
           Iterator<Candidat> it=ts.iterator();
		while (it.hasNext())	{
			c=it.next();
			if(nrLeg==c.getNrLegitimatie()) return c;
		}	
		return null;
	}
		
public void adaugaCandidat(String cnp, String n, String p){
	boolean b=ts.add(new Candidat(cnp, n, p));
	if(b)   JOptionPane.showMessageDialog(null, "Candidatul a fost adaugat in concurs", "Information", JOptionPane.INFORMATION_MESSAGE);
        else JOptionPane.showMessageDialog(null, "Candidatul exista deja! Nu a fost adaugat in concurs", "Information", JOptionPane.INFORMATION_MESSAGE);

}
	
public void eliminaCandidat(int nrLeg){
	for(Candidat c:ts)
	  if(nrLeg==c.getNrLegitimatie()) {
	    ts.remove(c);
	    JOptionPane.showMessageDialog(null, "Candidatul a fost eliminat din concurs", "Information", JOptionPane.INFORMATION_MESSAGE);
	    return;
	  }
	
	JOptionPane.showMessageDialog(null, "Candidatul nu participa la concurs", "Alert", JOptionPane.ERROR_MESSAGE);
}
public void reordoneazaCandidati(){
      TreeSet<Candidat> temp=new TreeSet<>(new CandidatComparator());
      for (Candidat c: ts) temp.add(c);
      ts=temp;
}

public void salveaza(){
try{
  pw=new PrintWriter(new FileWriter("candidati.txt"));
  for(Candidat c:ts) pw.println(c);
  pw.close();	
 }catch(IOException e){e.printStackTrace();}

}
	
public static ColectieCandidati getInstanta(){
	if (cc==null) cc=new ColectieCandidati();
	return cc;
}	
	
	
}