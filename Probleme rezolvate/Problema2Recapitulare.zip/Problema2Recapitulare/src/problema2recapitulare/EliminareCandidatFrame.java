package problema2recapitulare;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class EliminareCandidatFrame extends JFrame{
	private AscultatorECF a;
	private JTextField t;
	private JButton ok, c;
	
	public EliminareCandidatFrame(){
		super ("Eliminarea unui candidat");
		JPanel p=new JPanel();
		p.setBackground(Color.lightGray);	
		p.add(new JLabel("Introduceti numar legitimatie"));
		t=new JTextField(20);
		p.add(t);
		add(p);		
		
		p=new JPanel();
		a=new AscultatorECF();
		ok=new JButton("OK");
		ok.addActionListener(a);
		p.add(ok);
		
    c=new JButton("Cancel");
    c.addActionListener(a);
    p.add(c);

    add(p, BorderLayout.SOUTH);
		setSize(400,100);
		setLocation(300,300);	
		}
  
  private class AscultatorECF implements ActionListener{
  private  ColectieCandidati cc;

  AscultatorECF(){
 	cc=ColectieCandidati.getInstanta();
	 	 
  }
 public void actionPerformed(ActionEvent e){
 	if (e.getSource()==ok) {
 		cc.eliminaCandidat(Integer.parseInt(t.getText()));
 		t.setText("");
 	 }
 	else EliminareCandidatFrame.this.dispose();
 }
	
	
  }
	
	}