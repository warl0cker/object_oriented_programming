package problema2recapitulare;
public class Persoana{
 private String nume, prenume, cnp;
	
		
public Persoana(String cnp, String nume, String pren){
	this.cnp=cnp;	
	this.nume=nume;
	prenume=pren;
	}

public String getNume(){
	return nume;
}

public String getPrenume(){
	return prenume;
	}	
public String getCNP(){return cnp;}	
		
public String toString(){
	return cnp+" "+nume+" "+prenume;
	
	}	
	}