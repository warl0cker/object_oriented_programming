package problema2recapitulare;

import java.text.NumberFormat;

public class Candidat{
private Persoana p;
private double pNota, dNota;
private int nrLeg;
private static int id=0;
		
		
public Candidat(String cnp, String nume, String pren){
p=new Persoana(cnp, nume, pren);
nrLeg=++id;
}

public Candidat(int nrLeg, String cnp, String nume, String pren){
p=new Persoana(cnp, nume, pren);
this.nrLeg=nrLeg;
if (nrLeg>id)id=nrLeg;
}

public void setPrimaNota(double pn){
 pNota=pn;

}

public void setADouaNota(double an){
 dNota=an;
}	
	

public double calculeazaMedie(){
 return (pNota+dNota)/2;
}

public String toString(){
  return nrLeg+" "+p+" "+pNota+" "+dNota;
}

public String getInformatii(){
    NumberFormat nf= NumberFormat.getInstance();
    nf.setMaximumFractionDigits(2);
    return nrLeg+" "+p.getNume()+" "+p.getPrenume()+" "+nf.format(calculeazaMedie());
 }

public int getNrLegitimatie(){return nrLeg;}
	
}