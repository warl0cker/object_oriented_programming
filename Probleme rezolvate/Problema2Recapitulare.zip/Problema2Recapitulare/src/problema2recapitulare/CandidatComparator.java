package problema2recapitulare;
import java.util.*;
public class CandidatComparator implements Comparator<Candidat>{

public int compare(Candidat c1, Candidat c2){
	if(c2.calculeazaMedie()<c1.calculeazaMedie()) return -1;
         else if (c1.calculeazaMedie()==c2.calculeazaMedie()) return 0;
         return 1;
	}



}