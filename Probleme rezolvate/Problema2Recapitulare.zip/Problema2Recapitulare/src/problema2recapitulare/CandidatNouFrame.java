package problema2recapitulare;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class CandidatNouFrame extends JFrame{
	private JTextField nt, pt, ct;
	private JButton inscrie;
	private AscultatorCNF a;
	
	public CandidatNouFrame(){
	super ("Inscrierea unui candidat nou");
	JPanel p=new JPanel();
	p.setLayout(new GridLayout(4,2,10,10));
	p.setBackground(Color.lightGray);	
		
	p.add(new JLabel("CNP"));
    ct=new JTextField(20);
    p.add(ct);
		
	p.add(new JLabel("Nume"));
    nt=new JTextField(10);
    p.add(nt);
		
	p.add(new JLabel("Prenume"));
	pt=new JTextField(10);
	p.add(pt);
	add(p);
		
		a=new AscultatorCNF();
		p=new JPanel();
		inscrie=new JButton("Inscrie");
		inscrie.addActionListener(a);
		p.add(inscrie);

      add(p, BorderLayout.SOUTH);		
	setLocation(400,300);
	}
  
  private class AscultatorCNF implements ActionListener{
  private  ColectieCandidati cc;

  AscultatorCNF(){
 	cc=ColectieCandidati.getInstanta();	 	 
  }
 public void actionPerformed(ActionEvent e){
  if(e.getSource()==inscrie) {
  	if(!ct.getText().equals("")&&!nt.getText().equals("")&&!pt.getText().equals("")) cc.adaugaCandidat(ct.getText(), nt.getText(), pt.getText());
    CandidatNouFrame.this.dispose();
    }
  
 }
	
	
  }
	
	}