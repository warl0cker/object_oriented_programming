package problema2recapitulare;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class NoteCandidatFrame extends JFrame{
	private AscultatorNCF a;
	private JTextField pnt, dnt;
	private JTextArea ta;
	private JButton m, c;
	private Candidat ca;
	
	public NoteCandidatFrame(Candidat ca){
		super ("Inregistrarea notelor");
		this.ca=ca;
		JPanel p=new JPanel();
		p.setLayout(new GridLayout(3,2,10,10));
		
		p.add(new JLabel("Prima nota"));
    pnt=new JTextField(10);
    p.add(pnt);
		
    p.add(new JLabel("A doua nota"));
    dnt=new JTextField(10);
    p.add(dnt);
		
		m=new JButton("Memoreaza");
		a=new AscultatorNCF();
		m.addActionListener(a);
		p.add(m);

    c=new JButton("Cancel");
    c.addActionListener(a);
    p.add(c);

		add(p);		
    	
		setSize(175,175);
		setLocation(300,300);
                setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//		addWindowListener(new WindowAdapter(){
//		 public void windowClosing(WindowEvent we){
//		  NoteCandidatFrame.this.dispose();
//		 		 
//		 }});
		}
  
  private class AscultatorNCF implements ActionListener{
  private  ColectieCandidati cc;

  AscultatorNCF(){
 	cc=ColectieCandidati.getInstanta();
	 	 
  }
 public void actionPerformed(ActionEvent e){
 	if (e.getSource()==m){
            ca.setPrimaNota(Double.parseDouble(pnt.getText()));
            ca.setADouaNota(Double.parseDouble(dnt.getText()));
            cc.reordoneazaCandidati();
            JOptionPane.showMessageDialog(NoteCandidatFrame.this, "Notele au fost memorate");
            NoteCandidatFrame.this.dispose();		
 	}	
 	else if (e.getSource()==c) NoteCandidatFrame.this.dispose();
 }
	
	
  }
	
	}