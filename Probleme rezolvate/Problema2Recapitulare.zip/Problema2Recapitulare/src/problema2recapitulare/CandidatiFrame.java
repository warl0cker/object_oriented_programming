package problema2recapitulare;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class CandidatiFrame extends JFrame{
	private JTextArea ta;
	private ColectieCandidati cc;
	
	public CandidatiFrame(){
		super ("Lista candidatilor");
		JPanel p=new JPanel();
		p.setBackground(Color.lightGray);
		add(new JLabel("Toti candidatii"), BorderLayout.NORTH);
		ta=new JTextArea(20,100);
		cc=ColectieCandidati.getInstanta();
		ta.setText(cc.getCandidati());
		ta.setEnabled(false);
		ta.setBackground(Color.white);
		add(ta);
		
		setSize(400,300);
		setLocation(300,300);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
  
 	
	}