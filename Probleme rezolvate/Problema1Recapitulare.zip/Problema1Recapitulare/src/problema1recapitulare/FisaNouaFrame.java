package problema1recapitulare;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class FisaNouaFrame extends JFrame{
	private GestorEvenimenteFNF ec;
	private JTextField ft, lt, at, tt, aet;
	private JButton ok, cancel;
	
	public FisaNouaFrame(){
		super ("Adauga o fisa noua");
		JPanel p=new JPanel();
		p.setLayout(new GridLayout(5,2,10,10));
		p.setBackground(Color.lightGray);	
		
		
    p.add(new JLabel("Nume"));
    lt=new JTextField(10);
    p.add(lt);
	
	p.add(new JLabel("Prenume"));
		ft=new JTextField(10);
		p.add(ft);
		
    p.add(new JLabel("Adresa"));
    at=new JTextField(10);
    p.add(at);

    p.add(new JLabel("Numar telefon"));
    tt=new JTextField(10);
    p.add(tt);

 	p.add(new JLabel("Adresa e-mail"));
    aet=new JTextField(10);
    p.add(aet);
		add(p);
		
		ec=new GestorEvenimenteFNF();
		p=new JPanel();
		ok=new JButton("OK");
		ok.addActionListener(ec);
		p.add(ok);

    cancel=new JButton("Cancel");
    cancel.addActionListener(ec);
    p.add(cancel);
    add(p, BorderLayout.SOUTH);		
    setLocation(300,300);
		}
  
  private class GestorEvenimenteFNF implements ActionListener{
  private  AgendaTelefonica tnb;

  GestorEvenimenteFNF(){
 	tnb=AgendaTelefonica.getInstanta();	 	 
  }
 public void actionPerformed(ActionEvent e){
  if(e.getSource()==ok) {
  	tnb.adaugaFisa(lt.getText(), ft.getText(),at.getText(),tt.getText(), aet.getText());
    FisaNouaFrame.this.dispose();
    }
  else FisaNouaFrame.this.dispose();
 
 }
	
	
  }
	
	}