package problema1recapitulare;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class FereastraPrincipala extends JFrame{
	private GestorEvenimenteFP ec;
	private JButton[] b;
	
	public FereastraPrincipala(){
	 super ("Bine ati venit!");
	  JPanel p=new JPanel();	
	  p.setLayout(new GridLayout(3,2,10,10));
	  p.setBackground(Color.lightGray);	
	  String[] s=new String[]{"Creaza fisa noua", "Cauta fisa", "Sterge fisa", "Arata continut agenda telefonica", "Salveaza toate fisele"};
	  ec=new GestorEvenimenteFP();	
	 b=new JButton[5];	
	  for (int i=0; i<b.length; i++){
		b[i]=new JButton(s[i]);
		b[i].addActionListener(ec);
		p.add(b[i]);
 	   }
	add(p);	
	}
	
	private class GestorEvenimenteFP implements ActionListener{
		private JFrame f;
		
	 public void actionPerformed(ActionEvent e){
	 
	  if(e.getSource()==b[0]){
	      f=new FisaNouaFrame();
	  	f.setSize(400, 300);
	  	f.setVisible(true);
	  	  
	  }
	 else if(e.getSource()==b[1]){
	   f=new CautaFisaFrame();
         f.setVisible(true);
	 }
	 	
	 else if(e.getSource()==b[2]){
	   f=new StergeFisaFrame();
         f.setVisible(true);
       }
	 else if(e.getSource()==b[3]){
	   f=new FiseFrame();
         f.setVisible(true);
	  	  
	  }	
	 else {
 		AgendaTelefonica at=AgendaTelefonica.getInstanta();
	 	at.salveaza();
	 }
	 	
	 }	
 }
	

}