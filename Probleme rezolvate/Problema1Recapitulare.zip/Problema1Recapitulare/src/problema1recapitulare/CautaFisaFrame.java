package problema1recapitulare;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class CautaFisaFrame extends JFrame{
	private GestorEvenimenteCFF ec;
	private JTextField t;
	private JTextArea ta;
	
	public CautaFisaFrame(){
		super ("Cauta o fisa");
		JPanel p=new JPanel();
		
		p.add(new JLabel("Introduceti nume si prenume"));
    t=new JTextField(10);
    ec=new GestorEvenimenteCFF();
    t.addActionListener(ec);
		p.add(t);
		
    add(p, BorderLayout.NORTH);		
    ta=new JTextArea(20,50);

		add(ta);
		setSize(300,200);
		setLocation(300,300);
                setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		}
  
  private class GestorEvenimenteCFF implements ActionListener{
  private  AgendaTelefonica at;

  GestorEvenimenteCFF(){
 	at=AgendaTelefonica.getInstanta();
	 	 
  }
 public void actionPerformed(ActionEvent e){
 	if (e.getSource()==t){
             ta.setText(at.cautaFisa(t.getText()));
              t.setText("");
 	}	
 }
	
	
  }
	
	}