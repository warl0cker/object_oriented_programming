
package problema1recapitulare;

import javax.swing.*;
public class Problema1Recapitulare {

  public static void main(String[] args) {
   JFrame w=new FereastraPrincipala();
   w.setSize(375, 150);
   w.setLocation(300,300);	
   w.setVisible(true); 	
   w.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
