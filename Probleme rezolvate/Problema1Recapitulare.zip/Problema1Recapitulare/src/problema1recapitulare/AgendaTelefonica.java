package problema1recapitulare;
import java.util.*;
import java.io.*; 
import javax.swing.*;
public class AgendaTelefonica{
	private TreeSet<Fisa> ts;
	private BufferedReader br;
	private PrintWriter pw;
	private String l;
	private Fisa fisa;
	
	private static AgendaTelefonica instanta;
	
	private AgendaTelefonica(){
	 File f=new File("fise.txt");
	 ts=new TreeSet<>();
	  String[] s, s1;
	  String ae; 
	 if (f.exists()){
	 	try{
	 		br=new BufferedReader(new FileReader(f));
	 		while ((l=br.readLine())!=null){
	             s=l.split("_");
	             s1=s[0].split(" ");
	             ae=s[3];
	             if(s.length>4) ae+="_"+s[4];
	 			 fisa=new Fisa(s1[0], s1[1], s[1], s[2], ae);
	 			 ts.add(fisa);
	    }
	 	}catch(IOException ioe){ioe.printStackTrace();}	
	
	} else System.out.println("Fisierul nu exista");
	}		
	
	public String getFise(){
	 StringBuffer rez=new StringBuffer();
	 Iterator<Fisa> it=ts.iterator();
	 while (it.hasNext()) rez.append(it.next()+"\n");
	 return rez.toString();
	}
	
	
		
public void adaugaFisa(String nume, String prenume, String adresa, String numar, String ae){
	fisa=new Fisa(nume, prenume, adresa, numar, ae);
	if (ts.contains(fisa)) {
		JOptionPane.showMessageDialog(null, "Fisa electronica exista deja in agenda telefonica", "Alert", JOptionPane.ERROR_MESSAGE);
		return;
	}
	ts.add(fisa);
	JOptionPane.showMessageDialog(null, "A fost adaugata o noua fisa electronica", "Information", JOptionPane.INFORMATION_MESSAGE);

}
public String cautaFisa(String nume){
		for(Fisa f: ts)	if(nume.equals(f.getNume())) return f.toString();
		return "nu exista nicio fisa cu numele "+ nume;
	}
	
public void stergeFisa(String nume){
	Iterator<Fisa> it=ts.iterator();
	while (it.hasNext())	{
	  if(nume.equalsIgnoreCase(it.next().getNume())) {
	    it.remove();
	    JOptionPane.showMessageDialog(null, "Fisa a fost stearsa din agenda telefonica", "Information", JOptionPane.INFORMATION_MESSAGE);
	    return;
	  }
	}	
	JOptionPane.showMessageDialog(null, "Fisa nu se gaseste in agenda telefonica", "Alert", JOptionPane.ERROR_MESSAGE);
}

public void salveaza(){
try{
  pw=new PrintWriter(new FileWriter("fise.txt"));
  for(Fisa f: ts) pw.println(f);
  pw.close();	
 }catch(IOException e){e.printStackTrace();}

}
	
public static AgendaTelefonica getInstanta(){
	if (instanta==null) instanta=new AgendaTelefonica();
	return instanta;
}	
	
	
}