package problema1recapitulare;
public class Fisa implements Comparable<Fisa>{
		private String  nume, prenume, adresa, numarTelefon, adresaEmail;
		
		
		public Fisa(String nume, String prenume, String adresa, String nt, String ae){
			this.nume=nume;
			this.prenume=prenume;		
			this.adresa=adresa;
			numarTelefon=nt;
			adresaEmail=ae;
		}
	
	public String getNume(){
		return nume+" "+prenume;
	}

	public String toString(){
		return nume+" "+prenume+"_"+adresa+"_"+numarTelefon+"_"+adresaEmail;
	}
	
	
	
	public int compareTo(Fisa o){
	 return (nume+" "+prenume).compareTo(o.getNume());
	}
	
}