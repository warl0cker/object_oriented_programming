package problema1recapitulare;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class FiseFrame extends JFrame{
	private JTextArea ta;
	private AgendaTelefonica at;
	
	public FiseFrame(){
		super ("Agenda telefonica");
		add(new JLabel("Toate fisele"), BorderLayout.NORTH);
		ta=new JTextArea(20,200);
		at=AgendaTelefonica.getInstanta();
		ta.setText(at.getFise());
		ta.setEnabled(false);
		add(ta);
		setSize(500,300);
		setLocation(300,300);
                setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	}
  
 	
	}