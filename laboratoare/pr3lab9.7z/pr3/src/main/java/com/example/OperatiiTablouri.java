package com.example;
public interface OperatiiTablouri {
    public void adaugaElement(Object o);
    public Object getElement(int pozitie);
    public Object stergeElement(int pozitie);
    public boolean cautaElement(Object o);
    public void afiseazaElemente();
}
