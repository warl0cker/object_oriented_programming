package com.example;
//import java.util.Arrays;
import javax.swing.JOptionPane;
/**
 * Hello world!
 *
 */
public class App implements OperatiiTablouri
{   //Object o= new Object();

    Object[] v= new Object[10];
    int poz=0;
    public void adaugaElement(Object o){
        v[poz++]=o;
    }
    public Object getElement(int pozitie){
        return v[pozitie];
    }
    public Object stergeElement(int pozitie){
        return v[pozitie]=null;
    }
    public boolean cautaElement(Object o){
        //Arrays.sort(v);
        for(int i=0;i<v.length;i++) if(v[i]==o)return true;
            return false;
        

    }
    public void afiseazaElemente(){
        for(poz=0;poz<v.length;poz++){
            System.out.print(v[poz] + " ");
        }
    }
        
    public static void main( String[] args )
    {   App app=new App();
        String s="test1";
        String s2="test2";
        Integer a=20;
        Boolean b=false;
        Byte c=2;
        Double d=-12.21;
        app.adaugaElement(s);
        app.adaugaElement(s2);
        app.adaugaElement(a);
        app.adaugaElement(b);
        app.adaugaElement(c);
        app.adaugaElement(d);
        String s3=JOptionPane.showInputDialog("Introdu pozitia unui element");
        int nr=Integer.parseInt(s3);
        System.out.println(app.getElement(nr));
        JOptionPane.showMessageDialog(null,"Operatia de afisare s-a terminat.");
        System.out.println(app.cautaElement("test2"));
        System.out.println(app.cautaElement("test4"));
        System.out.println(app.cautaElement(false));
        JOptionPane.showMessageDialog(null,"Operatia de cautare s-a terminat.");
        app.afiseazaElemente();
        System.out.println('\n');
        s3=JOptionPane.showInputDialog("Introdu pozitia unui element pentru a il sterge");
        nr=Integer.parseInt(s3);
        app.v[nr]=app.stergeElement(nr);
        System.out.println("Elementul este acum: "+app.getElement(nr));
        app.afiseazaElemente();
        System.exit(0);
    }
}
